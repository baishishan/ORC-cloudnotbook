// pages/preview/preview.js
Page({

  data: {
    'imageSrc':''
  },
  onLoad: function (options) {
    this.setData({
      imageSrc:options.imageSrc
    })
    console.log(this.data.imageSrc)
  },
  backTap(){
    wx.navigateBack({
      delta: 1,
    })
  },
  okTap() {
    wx.navigateTo({
      url: '/pages/detectResult/detectResult?srcImage='+this.data.imageSrc,
    })
  }
})