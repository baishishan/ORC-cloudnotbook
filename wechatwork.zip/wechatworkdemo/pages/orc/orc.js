// pages/orc/orc.js
Page({
  data: {
    text:'这是由🐚和🐻共同开发的一款传图识字兼转换笔记的小程序。 功能简介： ORC功能可以传图识字，可以直接拍摄也可以上传相册照片，字体可以有微小倾斜但不能横着或倒着。笔记功能需要登录才可使用，可以进行修改、新建、删除、翻译等操作。(ORC尚在完善)',
  },
  takeTap(){
    wx.navigateTo({
      url:"/pages/camera/camera"
    })
  },
  chooseTap(){
    var that=this;
    wx.chooseImage({
      count:1,
      sourceType:['album'],
      success: res => {
        that.setData({
          temp:res.tempFilePaths
        })
        wx.navigateTo({
          url: '/pages/detectResult/detectResult?srcImage='+that.data.temp,
        })
      }
    })
  },
  feedback:function(){
    wx.redirectTo({
      url: '/pages/feedback/feedback',
    })
  },
})