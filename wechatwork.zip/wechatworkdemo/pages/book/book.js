const app = getApp()
const db = wx.cloud.database()
Page({
  data:{
        _ID:'',
        id:'',
        tempid:'',
        password:'',
        newpassword:'',
        SecretnoteDetial:'你的笔记中还没有内容哦~',
        SecretnoteTitle:'这是你的私密笔记',
        tempUser:[],
        Secret:false,
        Title:'示例笔记',
        Detial:'你的笔记中还没有内容哦',
        UserName:'',
        UserHeadImage:'',
        openid:'',
        Signature:'',
        temp:[],
        User:[],
        hidden:false,
        onemore:false,//true表示成功已经进入过一次私密笔记
        lockcolor:false,//false表示红色，true表示绿色
        lockUrl:"/images/锁.png",//锁图片的地址
        hiddenChange:true,//隐藏修改密码图标
      bookList:[
        {_id: "28ee4e3e608edc2914d3a17d76aae951", title: "示例笔记", detial: "你的笔记中还没有内容哦~"},
      ],//获取到数据库的所有数据存放在其中
      c:''
  },

  onLoad:function(options){
    var that=this;
    this.setData({onemore:app.globalData.passwordOneMore})//取onemore
  //进入页面马上拿到openid
  wx.cloud.callFunction({
    name:'getOpenid',
    data: {
      option: 'getInfo',
    },
    success: res=>{
      this.setData({
        openid: res.result.openId,
      })//将openid传到全局变量globalopenid方便其他页面调用
      app.globalData.globalopenid=this.data.openid,
      //比较数据库中有没有这个openid，有的话直接取出来，没有的话不行动，等待新用户点击登录按钮
      wx.cloud.callFunction({
        name: 'getOpenid',
        data: {
          option: 'compareId',
          openid:this.data.openid,
        },
        success: res => {//有用户则开始获取其数据存入User
          console.log(res)
          this.setData({
            User: res.result.data,
          })
          if(that.data.User.length!=0)
          {
            console.log('已有此用户')
          that.data.User.forEach(function(item,index){
            //拿出User的值赋给变量，在界面显示用户信息
            that.setData({
              hidden:true,
              UserName:item.UserName,
              UserHeadImage:item.UserHeadImage,
              openid:item.openid,
              tempid:item._id,
            })
          })
          //本用户已存在，说明已经有一个对应的数据库，则开始加载其中内容
          //开始加载名字=openid的笔记列表
           setTimeout(() => { 
            wx.cloud.callFunction({
              name: 'cloudbook',
              data: {
                option: 'getAll',
                openid:this.data.openid,
              },
              success: res => {
                this.setData({
                  bookList: res.result.data
                })
                this.data.bookList.forEach(function(item,index){
                  that.setData({
                    c:that.data.c+'0'
                  })
                })
                wx.showToast({
                  title: '列表加载完毕',
                })
              },
              fail: err => {
                console.log(err)
              }
            }) }, 1000);
          wx.cloud.callFunction({//获取用户私密笔记的密码存入全局变量
            name: 'getOpenid',
            data: {
                      option: 'findpassword',
                      openid:this.data.openid,
                      password:this.data.password,
            },
            success: res => {
              app.globalData.globalSecretPassword=res.result.data[0].password
              console.log("全局密码 ",app.globalData.globalSecretPassword)
            if(!this.data.onemore)//没有输入过正确的密码
              if(app.globalData.globalSecretPassword!=''&&app.globalData.globalSecretPassword!=undefined)//只要密码不为空，则将锁设置为红色
              {
                this.changeLockStatus(1)
                this.setData({
                  hiddenChange:false   //密码不为空，显示修改密码组件
                })
              }
            }
            })
          }
        else
        {
         //否则无此用户，展现初始笔记列表
          console.log('无此用户')
        }
      },
      })
    }
  })
  },
  
  
  
  getUserInfo:function(){//登录按钮
    var that=this;
    //点击按钮后才拿用户的其他信息,同时根据openid建库
    wx.getUserProfile({
      desc:'展示用户信息',
      success: res=>{
         this.setData({
          hidden:true,//拿到头像和昵称数据后隐藏登录按钮
          UserName: res.userInfo.nickName,
          UserHeadImage: res.userInfo.avatarUrl,
        })
        //拿到之后入user数据库（openid进页面时已经拿到）
        wx.cloud.callFunction({
          name:'getOpenid',
          data: {
            option: 'addInfo',
            addData:{
              openid:this.data.openid,
            UserName:this.data.UserName,
            UserHeadImage:this.data.UserHeadImage,
            }
          },
          //用户信息入库成功，开始添加同openid名的数据库
          success: res=>{
            console.log('添加用户信息完毕')
            wx.cloud.callFunction({
              name: 'getOpenid',
              data: {//传openid作为数据库名称
                option: 'creatdb',
                openid:this.data.openid,
              },
              success(){
                console.log('初始化完毕')
                 //新用户的对应数据库建立完毕，之后给数据库初始值
                     wx.cloud.callFunction({
                      name: 'cloudbook',
                   data: {
                  option: 'add',
                 openid:that.data.openid,
                 addData:{
                 detial:that.data.Detial,
               title:that.data.Title,
              }
            },
            success(){
              console.log('加载信息完毕')
              that.onLoad()
            }
          })
        }
      })
          },
          fail: err => {
            console.log(err)
          }
        })
      }
    })
  },
//修改操作，根据_id传递detial到notebook
    haulDetial:function(e){
    this.setData({//得到个人数据库中的_id，存进本页_ID属性
      _ID:e.currentTarget.dataset.value
    })
    wx.cloud.callFunction({//通过_id从数据库查询get到一整条data
      name: 'cloudbook',
      data: {
        option: 'get',
        openid:this.data.openid,
        _ID:this.data._ID,
      },
      success: res => {
        this.setData({
          temp: res.result.data,
        })//temp数组存全部数据，并且放到全部变量中
        app.globalData.temparray = this.data.temp
        //完成传参后才跳转
        wx.redirectTo({url: '/pages/notebook/notebook?new=false'})
      },
      fail: err => {
        console.log(err)
      }
    })
    },

delBy_Id:function(e){
  this.setData({//拿到_id
    _ID:e.currentTarget.dataset.value,
    id:e.currentTarget.dataset.id
  })
  setTimeout(() => {
    this.setData({
      c:this.data.c.substr(0,this.data.id)+'1'+this.data.c.substr(this.data.id+1,this.data.c.length),
    })
  }, 200);
  wx.cloud.callFunction({
    name: 'cloudbook',
    data: {
      option: 'delete',
      openid:this.data.openid,
      _ID:this.data._ID
    },
    success: res => {
      wx.showToast({
        title: '删除成功',
      })
      console.log("删除成功")
      // console.log(res)
    },
    fail: err => {
      console.log("删除失败")
      // console.log(err)
    }
  })
},

jumpToBook:function(){
  app.globalData.temparray = [];
  wx.redirectTo({url: '/pages/notebook/notebook?new=true'})
},
changeLockStatus(n){
  if(n==1)
  {
    this.setData({lockUrl:'/images/红锁.png'})
  }
  else
  {
    this.setData({lockUrl:'/images/锁.png'})
  }
},
// 以下为私密笔记部分

newPasswordIn(e){//新密码输入时触发
  this.setData({
    newpassword:e.detail.value,
  })
  wx.cloud.callFunction({//设置新密码
    name: 'getOpenid',
    data: {
      option: 'changePassword',
      openid:this.data.openid,
      newpassword:this.data.newpassword,
    },
    success: res => {
      app.globalData.globalSecretPassword=this.data.newpassword//更改对应全局变量
      if(app.globalData.globalSecretPassword!='')
      { this.changeLockStatus(1);}//新密码不为空，锁变红}
      else
      {this.changeLockStatus(0);}//新密码为空，锁变绿
      this.setData({onemore:false})//设为没有输入过正确密码
      wx.showToast({
        title: '修改密码成功',
      })
    },
  })
},

toPasswordChange(e){
  console.log("tochange")
  this.setData({
    showModal_:e.detail.change,
  })
},

passwordIn(e){
  console.log("passwordIn",app.globalData.globalSecretPassword)
  this.setData({
    password:e.detail.passWord,
    //拿到password，如果库中有，则比较是否相同，比较成功则进入，若库中没有则添加，若不对则提示密码错误
  })
  if(app.globalData.globalSecretPassword==''||app.globalData.globalSecretPassword==undefined)
  {//先判断密码是不是空的，是则设置为密码
    console.log('密码为空')
    wx.cloud.callFunction({//设置密码
      name: 'getOpenid',
      data: {
        option: 'addSecret',
        openid:this.data.openid,
        tempid:this.data.tempid,
        SecretnoteTitle:this.data.SecretnoteTitle,
        SecretnoteDetial:this.data.SecretnoteDetial,
        password:this.data.password,
      },
      success: res => {
        wx.showToast({
          title: '密码设置成功',
        })
        app.globalSecretPassword=this.data.password;//密码更改，同时更改对应的全局变量
        this.changeLockStatus(1);           //锁变红
        this.setData({
          hiddenChange:false,  //显示修改密码
          onemore:false,       //变为没有输入过正确密码
        })
        wx.redirectTo({
          url: '/pages/notebook/notebook?Secret=true'+'&SecretTitle='+this.data.SecretnoteTitle+'&SecretDetial='+this.data.SecretnoteDetial,
        })
      },
      fail:err=>{
        console.log(err)
      }
    })
  }
  else
  {
    if(app.globalData.globalSecretPassword==this.data.password)//密码正确
    {
      wx.cloud.callFunction({
        name: 'getOpenid',
        data: {
          option: 'findId',
          openid:this.data.openid,
        },
        success: res =>{
      wx.showToast({
      title: '密码正确',
    })//跳转notebook,并且标记上这是私密,传进私密笔记的内容
    app.globalData.passwordOneMore=true;//设置为输入过正确密码
    this.changeLockStatus(0);//锁变绿
    wx.redirectTo({
      url: '/pages/notebook/notebook?Secret=true'+'&SecretTitle='+res.result.data[0].SecretnoteTitle+'&SecretDetial='+res.result.data[0].SecretnoteDetial,
    })
  }
  })
  }
  else//密码不正确
  {
    wx.showToast({
      icon:'error',
      title: '密码错误',
    })
  }
  }
  //if(app.globalData.globalSecretPassword==this.data.password)
   /* wx.cloud.callFunction({
    name: 'getOpenid',
    data: {
      option: 'findpassword',
      openid:this.data.openid,
      password:this.data.password,
    },
    success: res => {
      // console.log(res.result.data[0].password)
        if(res.result.data[0].password!=undefined&&this.data.password==res.result.data[0].password){//有密码且密码正确
          wx.showToast({
            title: '密码正确',
          })//跳转notebook,并且标记上这是私密,传进私密笔记的内容
          wx.redirectTo({
            url: '/pages/notebook/notebook?Secret=true'+'&SecretTitle='+res.result.data[0].SecretnoteTitle+'&SecretDetial='+res.result.data[0].SecretnoteDetial,
          })
        }
        else if(res.result.data[0].password!=undefined&&this.data.password!=res.result.data[0].password){//有密码但不相等
          wx.showToast({
            icon:'error',
            title: '密码错误',
          })
        }
        else{//没有密码，则给一个初始化的新建的私密笔记，同时加入密码
          wx.showToast({
            title: '密码设置成功',
          })
          // console.log(this.data.tempid)
          wx.cloud.callFunction({
            name: 'getOpenid',
            data: {
              option: 'addSecret',
              openid:this.data.openid,
              tempid:this.data.tempid,
              SecretnoteTitle:this.data.SecretnoteTitle,
              SecretnoteDetial:this.data.SecretnoteDetial,
              password:this.data.password,
            },
            success: res => {
              wx.redirectTo({
                url: '/pages/notebook/notebook?Secret=true'+'&SecretTitle='+this.data.SecretnoteTitle+'&SecretDetial='+this.data.SecretnoteDetial,
              })
            },
            fail:err=>{
              console.log(err)
            }
          })
        }
      },
    }) */
 
  },
//点击按钮
Secret(){//先比较openid，如果库中有用户则出现弹窗，没有则提示先登录
  wx.cloud.callFunction({
    name: 'getOpenid',
    data: {
      option: 'findId',
      openid:this.data.openid,
    },
    success: res => {
      this.setData({
        tempUser: res.result.data,
      })
      // console.log(this.data.tempUser)
      if(this.data.tempUser.length!=0){//有此用户
        if(this.data.onemore)//已经输入过正确密码，直接跳转
        {
          wx.redirectTo({
            url: '/pages/notebook/notebook?Secret=true'+'&SecretTitle='+res.result.data[0].SecretnoteTitle+'&SecretDetial='+res.result.data[0].SecretnoteDetial,
          })
        }
        else{//跳出弹窗
        this.setData({
          showModal:true,
        })
      }
      }else{//无此用户，提示登录
        wx.showToast({
          icon:'error',
          title: '请先登录',
        })
      }
    },
  })
},
})

