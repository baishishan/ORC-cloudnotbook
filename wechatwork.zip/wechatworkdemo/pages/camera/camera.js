// pages/list/list.js
Page({
  data: {
    'takeBtnIcon':'/images/camera-take.png',
    'backIcon':'/images/camera-back.png',
    'switchCameraIcon':'/images/camera-switch.png',
    'imgsrc':''
  },
  cameraTakeTap()
  {
    var that=this;
    this.takePhoto();
    setTimeout(function(){
    console.log("src "+that.data.imgsrc),
    wx.navigateTo({
      url:"/pages/preview/preview?imageSrc="+that.data.imgsrc
    })
  
  },500);
  },
  cameraBackTap()
  {
    wx.navigateBack({
      delta: 1,
    })
  },
  takePhoto() {
    const ctx = wx.createCameraContext()
    ctx.takePhoto({
      quality: 'high',
      success: (res) => {
        this.setData({
          imgsrc: res.tempImagePath
        })
      },
    })
  },
})