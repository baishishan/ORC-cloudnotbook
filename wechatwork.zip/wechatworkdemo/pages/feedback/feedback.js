const db = wx.cloud.database()
Page({
  data: {
    feedbackdetial:'',
    onpenid:'',
  },
  onLoad:function(){
    wx.cloud.callFunction({
      name:'getOpenid',
      data: {
        option: 'getInfo',
      },
      success: res=>{
        console.log(res)
        this.setData({
          openid: res.result.openId,
        })
      }
    })
  },
  getDetial:function(e){
    this.setData({
      feedbackdetial:e.detail.value,
    })
  },
  onUnload:function(e){
    if(this.data.feedbackdetial!=''){
      console.log(this.data.openid)
      wx.cloud.callFunction ({
        name: 'cloudbook',
        data: {
          option: 'addfeedback',
          addData:{
            openid:this.data.openid,
            feedbackdetial:this.data.feedbackdetial,
          }
        },
        success:res=>{
          wx.showToast({
            title: '反馈提交成功',
          })
        }
      });
    }


  }
})