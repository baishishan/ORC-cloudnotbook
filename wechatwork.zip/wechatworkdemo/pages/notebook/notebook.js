const app = getApp()
const db = wx.cloud.database()
Page({
  data: {
    notedetial:'',
    notetitle:'',
    note_ID:'',
    Secret:false,//全程不用修改,保留值
    notetemp:[],//存一条对应库的一条数据，初始为空
    openid:'',//用来获取数据库名称
    new:'false',//用来判断是否是新建
    toTrans:false,//用来判断是否跳转去翻译页面
  },
  onLoad: function (options) {
    this.setData({
      statusBarHeight:app.globalData.statusBarHeight,
      navBarHeight:app.globalData.navBarHeight,
      openid: app.globalData.globalopenid,
    })
    //判断是否为新建的函数
    if(options.new=='true'){//是新建的，则给初始化内容
      this.setData({
        notetemp: '',
        new:options.new,
      })
    }
    else if(options.Secret=='true'){//是私密笔记,传值
      this.setData({
        notedetial:options.SecretDetial,
        notetitle:options.SecretTitle,
        Secret:options.Secret,//让本地值等于传进来的值
      })
    }
    else{//非新建、非私密，即要修改的。需把上一页面传来的参数传进去
    this.setData({
      notetemp: app.globalData.temparray,
      new:options.new,
    })   
  }//判断结束
  // console.log(this.data.notetemp)
    var that=this;
    if(this.data.notetemp.length!=0){//非空，则需要修改，开始传各个参数
    that.data.notetemp.forEach(function(item,index){
      that.setData({
        notedetial:item.detial,
        notetitle:item.title,
        note_ID:item._id
      })
    })
    //保存三个参数
    app.globalData.tempdetial=app.globalData.temparray[0].detial
    app.globalData.temptitle=app.globalData.temparray[0].title
    app.globalData.temp_id=app.globalData.temparray[0]._id
  }
  else if(this.data.notetemp.length==0&&options.Secret=='false'){//空且非私密,即新建页
    that.setData({
      notedetial:'',
      notetitle:'',
    })
    app.globalData.tempdetial=''
    app.globalData.temptitle=''
  }
  else{//是私密页,啥都不做
    app.globalData.tempdetial=''
    app.globalData.temptitle=''
  }
  },

  onUnload(){
    if(!this.data.toTrans){//如果不是去翻译界面
      if(this.data.Secret=='true')//如果是私密
      {
        wx.cloud.callFunction({//更新私密笔记
          name: 'getOpenid',
          data: {
            option: 'update',
            openid:this.data.openid,
            notedetial:this.data.notedetial,
            notetitle:this.data.notetitle,
          },
          success: res => {
            wx.showToast({
              title: '保存成功',
            })
            console.log('保存成功')
          },
          fail: err => {
            console.log("修改失败")
            console.log(err)
          }
        })
      }
      else{//普通笔记
           if(this.data.new=='true')//如果是新建的
           {
            if(app.globalData.tempdetial!=''||app.globalData.temptitle!='')//标题或者内容不为空时，添加进数据库
            {
              wx.cloud.callFunction ({
                   name: 'cloudbook',
                   data: {
                     openid:this.data.openid,
                     option: 'add',
                     addData:{
                       detial:app.globalData.tempdetial,
                       title:app.globalData.temptitle,
                     }
                   },
                   success: res => {
                     wx.showToast({
                       title: '新建成功',
                     })
                   },
                   fail: err => {
                     console.log("新建失败")
                     console.log(err)
                   }
                 });
               }
           }
           else//不是新建的，即修改
           {
            wx.cloud.callFunction({
              name: 'cloudbook',
              data: {
                option: 'update',
                openid:this.data.openid,
                note_ID:app.globalData.temparray[0]._id,
                notedetial:app.globalData.tempdetial,
                notetitle:app.globalData.temptitle,
              },
              success: res => {
                wx.showToast({
                  title: '保存成功',
                })
                // console.log(app.globalData)
                console.log('保存成功')
              },
              fail: err => {
                console.log("修改失败")
                console.log(err)
              }
            })
           }
      }
    }else{//去翻译页面
    }
    }, 

  changeDetial:function(e){
    this.setData({
      notedetial:e.detail.value
    })
    app.globalData.tempdetial=this.data.notedetial;
  },
  changeTitle:function(e){
    this.setData({
      notetitle:e.detail.value
    })
    app.globalData.temptitle=this.data.notetitle;
  },

  JumpToTrans:function(){
    this.setData({
      toTrans:true,
    })
    if(this.data.new=='false'&&this.data.Secret=='true'){//为私密页面，则传到翻译页面标题和内容，给一个hidden标记
      wx.redirectTo({
        url: '/pages/trans/trans?hidden=true'+'&tempdetial='+this.data.notedetial+'&temptitle='+this.data.notetitle,
      })
    }
    else{//非私密页面,分为两部分
      
      // console.log(this.this.data.note_ID)
      if(this.data.new=='true'){//若是新建页面,跳转的时候给个判断new=true
        wx.redirectTo({
        url: '/pages/trans/trans?tempdetial='+this.data.notedetial+'&temptitle='+this.data.notetitle+'&temp_id='+this.data.note_ID+'&new=true',
      })
      }
      else
      {//若不是新建页面,跳转的时候给个判断new=false
        wx.redirectTo({
        url: '/pages/trans/trans?tempdetial='+this.data.notedetial+'&temptitle='+this.data.notetitle+'&temp_id='+this.data.note_ID+'&new=false',
      })
      }
  }
  }
})
