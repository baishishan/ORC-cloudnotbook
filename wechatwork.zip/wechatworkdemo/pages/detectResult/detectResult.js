// pages/detect/detect.js
const app=getApp()
Page({
  data: {
  'temp':'',
  'text':'',
  'baiduToken':'',
  'imageData':'',
  'title':'识别结果',
  detial:'未识别',
  showModal: false,
  openid:'',
},
onLoad: function (options) {
  var that=this;
  //此页面也得拿到openid才能查询库，不然云函数调用错误
  wx.cloud.callFunction({
    name:'getOpenid',
    data: {
      option: 'getInfo',
    },
    success: res=>{
      this.setData({
        openid: res.result.openId,
      })
    },
  })
  this.getBaiduTaken();
  let {
    statusBarHeight,
    navBarHeight
} = app.globalData;
  this.setData({
    temp:options.srcImage,
    openid: app.globalData.globalopenid,
    statusBarHeight,
    navBarHeight
  })
  wx.getFileSystemManager().readFile({
    filePath: that.data.temp, //选择图片返回的相对路径
    encoding: 'base64', //编码格式
    success: res => { //成功的回调
      that.setData({
        imageData:res.data
      })
    }
  })
},

getBaiduTaken()
{
  const apikey='x4xhHoi2vi5NQRNjYUhkm3TP';
  const seckey='OxpFnnjorzmbNY8FiBbBBkjueY2cc3FI';
  const tokenUrl='https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=dxWmGl7vgPXyi8u838vMnUu7&client_secret=VeQ2XciWWGTrCMLoVyRFevjTi3ATGloN';
  var that=this;
  wx.request({
    url: tokenUrl,
    method:'POST',
    dataType:'json',
    header:{
      'content-type':'application/json; charset=UTF-8'
    },
    success(res)
    {
      console.log("success",res);
      that.setData({
        baiduToken:res.data.access_token
      })
    },
    fail(res)
    {
      console.log("fail",res);
    }
  })
},
getImage(res){
  var that=this;
  wx.chooseImage({
    success: res => {
      that.setData({
        temp:res.tempFilePaths
      })
      console.log("success choose",res)
    wx.getFileSystemManager().readFile({
        filePath: res.tempFilePaths[0], //选择图片返回的相对路径
        encoding: 'base64', //编码格式
        success: res => { //成功的回调
          that.setData({
            imageData:res.data
          })
        }
      })
    }
  })
},
 scanImage(res){
  var that=this;
  const detectUrl='https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic?access_token=$'+that.data.baiduToken;
  console.log("detect "+this.data.temp)
  wx.showLoading({
    title:"识别中"
  });
   wx.request({
      url: detectUrl,
      data:{
        image:this.data.imageData
      },
      method:"POST",
      dataType:'json',
      header:{
        'content-type':'application/x-www-form-urlencoded'
      },
      success:res=>{
        console.log('detect success')
      },
      fail:res=>{
        console.log('detect fail')
      },
      complete:res=>{
        wx.hideLoading()
        console.log('detect complete')
        console.log(res)
        that.setData({
          word:res.data.words_result
        })
        setTimeout(function(){
          that.setData({
            text:''
          })
          console.log(that.data.word)
          if(that.data.word.length!=0)
          {
            that.data.word.forEach(function(item,index){
            that.setData({
              text:that.data.text+that.data.word[index].words+'\n'
            })
          })   
        }
        else
        {
          that.setData({
            text:"未识别到文字"
          })
        };
      },1000)
      }
    });
  },
mytap(){
  this.scanImage();
},
inputWord(e){
  var that=this;
  that.setData({
    text:e.detail.value
  })
},
add(){
  wx.cloud.callFunction({
    name: 'cloudbook',
    data: {
      option: 'add',
      openid:this.data.openid,
      addData:{
        title:this.data.title,
        detial:this.data.text
      }
    },
    success: res => {
      wx.showToast({
        title: '笔记保存成功',
      })
      console.log("添加成功")
      console.log(res)
      wx.switchTab({url: '/pages/book/book'})
    },
    fail: err => {
      wx.showToast({
        icon:'error',
        title: '请先登录',
      })
      // console.log(err)
    }
  })
},
m(e){
  this.setData({
    title:e.detail.value,
    detial:this.data.text
  })
  this.add();
},
saveTap(){//保存为新笔记
  this.setData({
    showModal:true
  })
},
copyTap(){
  wx.setClipboardData({
    data: this.data.text,
  })
}
})