
Component({
  options: {
      multipleSlots: true
  },
  properties: {//属性列表
      setPssword:{
          type: String,
          value: ''
      },
      showModal:{
        type:Boolean,
        value:false
      },
      passWord:{
        type: String,
        value: ''
    },
    hiddenChange:{
      type: Boolean,
      value: true
  },
  },
  data: {
    showModal: false,
    // showModal_:false,
    setPassword:'请输入6位数密码',//提示
    passWord:'',//输入框中的内容
    returnPassword:''
  },

  methods: {
   back:function(){
     this.setData({
       showModal:false
     })
   },
   changePW:function(){//如果点击修改密码，则隐藏此弹窗，并返回另一个弹窗的showModal值
    this.setData({
      showModal:false,
      passWord:'',
    })
    this.triggerEvent('change', {change:true},{})//返回用户输入的登录密码
  },
   wish_put:function(e){
     this.setData({
      passWord:e.detail.value
     })
   },
   ok:function(){
    //  console.log(this.data.passWord);
     this.setData({
       showModal:false,
       returnPassword:this.data.passWord,
     })
     this.triggerEvent('ok', {passWord:this.data.returnPassword},{})//返回用户输入的登录密码
     this.setData({
      passWord:'',
    })
   }
  }
})