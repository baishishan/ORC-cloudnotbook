
Component({
  options: {
      multipleSlots: true
  },
  properties: {//属性列表
      setPssword:{
          type: String,
          value: ''
      },
      showModal:{
        type:Boolean,
        value:false
      },
      passWord:{
        type: String,
        value: ''
    },
  },
  data: {
    showModal_:false,
    setword:'请输入6位新密码',//提示
    passWord:'',//输入框中的内容
    newPassword:''
  },

  methods: {
   back:function(){
     this.setData({
      showModal:false
     })
   },
   wish_put:function(e){
     this.setData({
      passWord:e.detail.value
     })
   },
   ok:function(){
    //  console.log(this.data.passWord);
     this.setData({
       showModal:false,
       newPassword:this.data.passWord
     })
     this.triggerEvent('ok', {value:this.data.newPassword},{})//返回新密码
     this.setData({
      passWord:''
    })
   }
  }
})