const app = getApp()
Component({
    options: {
        multipleSlots: true
    },
    properties: {
        backgroundColor:{
            type: String,
            value: ''
        },
        textValue:{
            type:String,
            value:'title'
        },
        back: {
            type: Boolean,
            value: false
          },
          home: {
            type: Boolean,
            value: false
          },
          reUrl:{
              type:String,
              value:''
          }
    },
    data: {
    },
    ready() {
        let {
            statusBarHeight,
            navBarHeight
        } = app.globalData;

        this.setData({
            statusBarHeight,
            navBarHeight
        })
    },
    methods: {
        backHome: function () {
            wx.reLaunch({
              url: '../orc/orc',
            })
          },
          back: function () {
        if(this.data.reUrl==''){
            wx.navigateBack({
              delta: 1
            })
        }
        else{
            wx.reLaunch({
              url: this.data.reUrl,
            })
        }
          }      
    }
})
