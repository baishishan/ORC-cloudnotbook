
Component({
  options: {
      multipleSlots: true
  },
  properties: {
      settitle:{
          type: String,
          value: ''
      },
      preTitle:{
          type:String,
          value:''
      },
      showModal:{
        type:Boolean,
        value:false
      }
  },
  data: {
    showModal: false,
    'settitle':'输入新笔记标题',//设置标题
    'preTitle':''//预输入的标题
  },

  methods: {
    eject:function(){
      this.setData({
        showModal:true
      })
    },
   back:function(){
     this.setData({
       showModal:false
     })
   },
   wish_put:function(e){
     this.setData({
       preTitle:e.detail.value
     })
   },
   ok:function(){
     console.log(this.data.preTitle);
     this.setData({
       showModal:false
     })
     this.triggerEvent('myevent', {value:this.data.preTitle},{})
   }
  }
})