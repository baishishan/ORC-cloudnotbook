// 云函数入口文件
const cloud = require('wx-server-sdk');

cloud.init();

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  //获取数据库的连接对象
  const db = cloud.database();

 //增
 if(event.option=='add'){
  return await db.collection(event.openid).add({
    data:event.addData
});
 }
//在反馈库中增
 if(event.option=='addfeedback'){
  return await db.collection('Feedback').add({
    data:event.addData
});
 }

 //删
else if(event.option=="delete"){
  return await db.collection(event.openid).where({
    _id:event._ID
  }).remove();
}

//获取全部
else if(event.option=="getAll"){
  return await db.collection(event.openid).get({
    success:function(res){
      return res;
    }
  });
}

//查
else if(event.option=="get"){
  return await db.collection(event.openid).where({
    _id:event._ID,
  }).get({
    success:function(res){
      return res;
    }
  });
}

//改内容
else if(event.option=="updateDetial"){
  return await db.collection(event.openid).where({
    _id:event.note_ID
  }).update({
    data:{
      detial:event.notedetial,
    }
  });
}
//改标题
else if(event.option=="updateTitle"){
  return await db.collection(event.openid).where({
    _id:event.note_ID
  }).update({
    data:{
      title:event.notetitle,
    }
  });
}
//改全部notebook中用
else if(event.option=="update"){
  return await db.collection(event.openid).where({
    _id:event.note_ID
  }).update({
    data:{
      title:event.notetitle,
      detial:event.notedetial,
    }
  });
}
//连接原笔记
else if(event.option=="connect"){
  return await db.collection(event.openid).where({
    _id:event.id
  }).update({
    data:{
      detial:event.detail,
    }
  });
}
}