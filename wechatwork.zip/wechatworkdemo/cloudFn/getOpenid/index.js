// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  const db = cloud.database();
  var tempName = '';
  if(event.option=="creatdb"){
    return await db.createCollection(event.openid)
  }

  else if(event.option=="getInfo"){
    return event.userInfo; //返回用户openid信息
  }

  else if(event.option=="addInfo"){
    return await db.collection('user').add({
      data:event.addData
  });
  }
//对比数据库中的数据，如果有则传出图、名
  else if(event.option=="compareId"){
    return await db.collection('user').where({
      openid:event.openid,
    }).get({
      success:function(res){
        return res;
      }
    });
  }

  else if(event.option=="findpassword"){
    return await db.collection('user').where({
      openid:event.openid,
      // password:event.password,
    }).get({
      success:function(res){
        return res;
      }
    });
  }
  else if(event.option=="findId"){
    return await db.collection('user').where({
      openid:event.openid,
    }).get({
      success:function(res){
        return res;
      }
    });
  }
  //更新用户的私密笔记的标题和内容
  else if(event.option=="update"){
    return await db.collection('user').where({
      openid:event.openid,
    }).update({
      data:{
        SecretnoteTitle:event.notetitle,
        SecretnoteDetial:event.notedetial,
      }
    });
  }
  //给用户库添加新字段（未实现，云函数语法错误）await
  else if(event.option=="addSecret"){
    return db.collection('user')
    .where({_id:event.tempid})
    .update({
      data:{
        SecretnoteTitle:event.SecretnoteTitle,
        SecretnoteDetial:event.SecretnoteDetial,
        password:event.password,
      }
  });
  }
  //连接原私密笔记
else if(event.option=="connect"){
  return await db.collection('user').where({
    openid:event.openid
  }).update({
    data:{
      SecretnoteDetial:event.detail,
    }
  });
}
else if(event.option=="changePassword"){
  return await db.collection('user').where({
    openid:event.openid
  }).update({
    data:{
      password:event.newpassword,
    }
  });
}
  }