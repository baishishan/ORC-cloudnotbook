// app.js
App({
  globalData: {
    temparray:[],//存一条记录book to notebook
    tempUser:[],//存全部数据库记录
    //存notebook to trans的三个参数
    tempdetial:'',
    temptitle:'',
    temp_id:'',
    statusBarHeight: 0,
    screenHeight: 0,
    globalopenid:'',
    globalSecretPassword:'',//全局私密笔记密码
    passwordOneMore:false,//输入正确密码多于1次
  },
  onLaunch: function () {
    //云开发函数的初始化
    wx.cloud.init(
      {
        env:"cloud1-5gb1mi7ab2903340"
      },
      wx.getSystemInfo({
        success: (res) => {
            this.globalData.statusBarHeight = res.statusBarHeight
            this.globalData.navBarHeight = 44 + res.statusBarHeight
        }
      })
    )

    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
})
